##########################
Jupyter Notebook Examples
##########################

OneD Example
-------------------------------------------

.. toctree::
    :maxdepth: 2
    :caption: Example:

    example.ipynb