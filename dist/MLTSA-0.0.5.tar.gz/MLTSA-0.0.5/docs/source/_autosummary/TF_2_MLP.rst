﻿TF\_2\_MLP
==========

.. currentmodule:: TF_2_MLP

.. automodule:: TF_2_MLP