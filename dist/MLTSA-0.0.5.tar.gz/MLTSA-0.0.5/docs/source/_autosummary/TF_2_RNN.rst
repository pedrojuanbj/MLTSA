﻿TF\_2\_RNN
==========

.. currentmodule:: TF_2_RNN

.. automodule:: TF_2_RNN