#############################################
Analytical One-Dimensional model module
#############################################

These are the functions that the analytical model provides

.. automodule:: OneD_pot_data
    :members:

